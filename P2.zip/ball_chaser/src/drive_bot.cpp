/*
 *MIT License
 *
 *  Copyright (c) 2019 Pranav Dhulipala
 *
 *  AUTHOR : PRANAV DHULIPALA
 *  AFFILIATION : UNIVERSITY OF MARYLAND COLLEGE PARK
 *  EMAIL : PRANAV95@UMD.EDU
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *  The above copyright notice and this permission notice shall be included in all
 *  copies or substantial portions of the Software.
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 *
 *
 *
 *  Program: drive_bot
 *
 */
/**
 *  @file drive_bot.cpp
 *  @brief Contains declarations used for the drive bot
 *
 *  This file has the definitions of the methods to move the robot
 *
 *
 *
 *
 *
 *
 *  @author Pranav Dhulipala
 *  @date   06/26/2019
 */
#include "ros/ros.h"
#include "geometry_msgs/Twist.h"
#include "ball_chaser/DriveToTarget.h"

ros::Publisher motor_command_publisher;

bool drive_request_handler(
    ball_chaser::DriveToTarget::Request& req,
    ball_chaser::DriveToTarget::Response& res) {
  ROS_INFO(
      "DriveToTargetRequest received - linear velocity.:%1.2f, angular velocity.:%1.2f",
      (float) req.linear_x, (float) req.angular_z);
  geometry_msgs::Twist motor_command;
  motor_command.linear.x = (float) req.linear_x;
  motor_command.angular.z = (float) req.angular_z;
  motor_command_publisher.publish(motor_command);
  res.msg_feedback = "Requested linear and angular velocities set";
  ROS_INFO_STREAM(res.msg_feedback);
  return true;

}

int main(int argc, char** argv) {

  ros::init(argc, argv, "drive_bot");
  ros::NodeHandle n;
  motor_command_publisher = n.advertise < geometry_msgs::Twist
      > ("/cmd_vel", 10);
  ros::ServiceServer service = n.advertiseService("/ball_chaser/command_robot",
                                                  drive_request_handler);
  ROS_INFO("Sending joint commands");
  ros::spin();
  return 0;
}

