/*
 *MIT License
 *
 *  Copyright (c) 2019 Pranav Dhulipala
 *
 *  AUTHOR : PRANAV DHULIPALA
 *  AFFILIATION : UNIVERSITY OF MARYLAND COLLEGE PARK
 *  EMAIL : PRANAV95@UMD.EDU
 *
 *  Permission is hereby granted, free of charge, to any person obtaining a copy
 *  of this software and associated documentation files (the "Software"), to deal
 *  in the Software without restriction, including without limitation the rights
 *  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *  copies of the Software, and to permit persons to whom the Software is
 *  furnished to do so, subject to the following conditions:
 *  The above copyright notice and this permission notice shall be included in all
 *  copies or substantial portions of the Software.
 *  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 *  SOFTWARE.
 *
 *
 *
 *  Program: process_image
 *
 */
/**
 *  @file process_image.cpp
 *  @brief Contains declarations used for process_image
 *
 *  This file has the declarations of the methods to to process the image
 *
 *
 *
 *
 *
 *
 *  @author Pranav Dhulipala
 *  @date   06/26/2019
 */
#include "ros/ros.h"
#include<iostream>
#include <sensor_msgs/Image.h>
#include "ball_chaser/DriveToTarget.h"

ros::ServiceClient client;

void drive_robot(float lin_x, float ang_z) {
  ROS_INFO_STREAM("Moving the robot");
  ball_chaser::DriveToTarget srv;
  srv.request.linear_x = lin_x;
  srv.request.angular_z = ang_z;

  if (client.call(srv)) {
    ROS_INFO("Calling Service");
  } else {
    ROS_ERROR("Failed to call service");
  }
}

void process_image_callback(const sensor_msgs::Image img) {
  int white = 255;

  int left_count = 0;
  int mid_count = 0;
  int right_count = 0;
  int left_thresh = img.width / 3;
  int mid_thresh = 2 * img.width / 3;
  int R = 0;
  int G = 0;
  int B = 0;

  for (int i = 0; i < img.height; i++) {
    for (int j = 0; j < img.width; j++) {
      R = img.data[i * img.step + j * 3];
      G = img.data[i * img.step + j * 3 + 1];
      B = img.data[i * img.step + j * 3 + 2];
      if ((R == white) && (G == white) && (B == white)) {
        if (j < left_thresh) {
          left_count += 1;
        } else if (j < mid_thresh) {
          mid_count += 1;
        } else {
          right_count += 1;
        }
      }
    }
  }
  //std::cout << mid_count;
  if (left_count || mid_count || right_count) {
    if ((right_count > mid_count) && (right_count > left_count)) {
      drive_robot(0.3, -0.6);
    } else if (mid_count > left_count) {
      drive_robot(0.3, 0);
    } else {
      drive_robot(0.3, 0.6);
    }
  } else {
    drive_robot(0, 0);
  }

}

int main(int argc, char** argv) {
  ros::init(argc, argv, "process_image");
  ros::NodeHandle n;
  client = n.serviceClient < ball_chaser::DriveToTarget
      > ("/ball_chaser/command_robot");
  ros::Subscriber sub = n.subscribe("/camera/rgb/image_raw", 10,
                                    process_image_callback);
  ros::spin();

  return 0;
}

