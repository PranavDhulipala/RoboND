# Testing Model Views

Test the robot descriptions via the launcher in 
turtlebot_viz/turtlebot_rviz_launchers.

    roslaunch turtlebot_rviz_launchers view_model.launch

It is a standalone launcher with minimal dependencies. Comments
on how to reconfigure your environment to view the different
robot models are in the launcher.
